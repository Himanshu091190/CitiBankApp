import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
@Injectable()
export class MyServicesService {

  constructor() { }

  log(message: any) {
    console.log(message);
  }
}
