import { Component, Inject, OnInit } from '@angular/core';
import { DashboardServiceService } from './dashboard-service.service';
import { HomeService } from './home.service';
import { Observable , of } from 'rxjs';
import { NumberSymbol } from '@angular/common';
import { ValueConverter } from '@angular/compiler/src/render3/view/template';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit{

  ngOnInit() {
    // Observable from Array
    // const array = [1,2,3,4,5,6,7]
    // const obsof1 = of(array);

    // const array1 = [1,2,3,4,5,6,7]
    // const array2 = ["a","b","c","d","e","f","g"]
    // const obsof1 = of(array1 , array2);


    // Observable from a Sequence of NumberSymbol
    // const obsof1 = of(1,2,3,4,5,6,7);

    // Obserevable from a string
      //  const obsof1 = of("a","b","c","d","e","f","g");

    // Observable from a ValueConverter, Array & String
    const obsof1 = of(100,[1,2,3,4,5,6,7],"abcdefg");
    
    obsof1.subscribe( val => console.log(val),
    error => console.log("error"),
    () => console.log("Completed"))
  }
  
// obs = new Observable((observer) => {
//   console.log("Observable Starts")
//   setTimeout(() => {observer.next("1")} , 1000 );
//   setTimeout(() => {observer.next("2")} , 2000 );
//   setTimeout(() => {observer.next("3")} , 3000 );
//   setTimeout(() => {observer.complete()} , 3500 );
//   setTimeout(() => {observer.next("4")} , 4000 );
//   setTimeout(() => {observer.next("5")} , 5000 );
// });

// ngOnInit() {
//   this.obs.subscribe(
//     val => { console.log(val) },
//     error => { console.log("error") },
//     () => { console.log("Completed") }
//   )
// }
  // counter =  5;

  // increment() {
  //   this.counter++;
  // }

  // decrement() {
  //   this.counter--;
  // }

  // countChangeHandler(count: number) {
  //   this.counter = count;
  // }

  // title = 'MyAngularApp';
  // todayDate = new Date();
  // jsonValue = {name:'Himanshu', age:30, address:{a1:'New Delhi',a2:'India'}};
  // months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sept','Oct','Nov','Dec'];

  // isLoggedIn: boolean = true;
  
  // Designation: string | undefined;
  // TotalNumberofProjects: number | undefined;
  // NoOfPendingProjects: number | undefined;
  // NoOfCompletedProjects: number | undefined;
  // NoOfProjectsTobeStarted: number | undefined;

  // Companies: string[] | undefined;
  // Years: number[] = [];
  // TotalEmployeesSummary: any = [];

  // // constructor(private dashboardService: DashboardServiceService) {
  // // }

  
  // constructor(private homeService: HomeService) {
  // }

  // ngOnInit(): void {
  //   console.log("Inside ngOnInit Method");
  //   this.Designation = "Team Leader";
  //   this.TotalNumberofProjects = 254;
  //   this.NoOfPendingProjects = 54;
  //   this.NoOfCompletedProjects = 100;
  //   this.NoOfProjectsTobeStarted = 100;

  //   this.Companies = ["ABC Solutions","DEF Technology", "GHI Industries", "JKL Inforsystems",
  // "MNO Solutions INC."];
    
  //   for( var i = 2021; i >= 2016; i-- ) 
  //     this.Years.push(i);

  //   // this.TotalEmployeesSummary = [
  //   //   {Region: "EAST", TotalStrength: 50, unUsedStrength: 20},
  //   //   {Region: "WEST", TotalStrength: 40, unUsedStrength: 10},
  //   //   {Region: "NORTH", TotalStrength: 30, unUsedStrength: 5},
  //   //   {Region: "SOUTH", TotalStrength :45, unUsedStrength: 13},
  //   //   {Region: "CENTRAL", TotalStrength: 55, unUsedStrength: 18}
  //   // ];

  //   // this.TotalEmployeesSummary = this.dashboardService.getTotalEmployeesSummary();
  //   this.TotalEmployeesSummary = this.homeService.getDashBoardServiceTeams();
  // }

  // onProjectChange($event: any) {
  //   console.log($event.target.value)
  //   if($event.target.value == "Project A") {
  //     this.Companies = ["Company A","Company A1", "Company A2", "Company A3", "Company A4"];
  //   }
  //   else if($event.target.value == "Project B") {
  //     this.Companies = ["Company B","Company B1", "Company B2", "Company B3", "Company B4"];
  //   }
  //   else if($event.target.value == "Project C") {
  //     this.Companies = ["Company C","Company C1", "Company C2", "Company C3", "Company C4"];
  //   }
  // }

  // setTitle($event: any) {
  //   this.title = $event.target.value;
  // }
  // clearTitle() {
  //   this.title = "";
  // }

  // ngOnChanges() {
  //   console.log("Inside ngOnChanges Method");
  //   }
    
  //   ngDoCheck() {
  //   console.log("Inside ngDoCheck Method");
  //   }
  //   ngAfterContentChecked() {
  //   console.log("Inside ngAfterContentChecked Method");
  //   }
  //   ngAfterViewInit() {
  //   console.log("Inside ngAfterViewInit Method");
  //   }
  //   ngAfterViewChecked() {
  //   console.log("Inside ngAfterViewChecked Method");
  //   }
  //   ngOnDestroy() {
  //   console.log("Inside ngOnDestroy Method");
  //   }

}

