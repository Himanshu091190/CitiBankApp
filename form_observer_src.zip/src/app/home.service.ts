import { Inject, Injectable } from '@angular/core';
import { DashboardServiceService } from './dashboard-service.service';
import { MyServicesService } from './services/my-services.service';

// @Injectable({
//   providedIn: 'root'
// })

@Injectable()
export class HomeService {

  constructor(@Inject(DashboardServiceService) private dashboardService:any , 
  @Inject(MyServicesService) private myService: any) {
    this.dashboardService.log("Instantiating the Dashboard Service");
    this.myService.log("I am the method of myService which is injected in Home Service.");
    
   }

   public getDashBoardServiceTeams() {
    return this.dashboardService.getTotalEmployeesSummary();
   }
}
