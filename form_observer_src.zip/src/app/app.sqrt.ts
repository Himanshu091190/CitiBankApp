import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    // name: 'sqrt'
    // name: 'square'
    name: 'power'
})

export class SqrtPipe implements PipeTransform {
    // transform(val:number): number {
    //     return Math.sqrt(val);
    // }
    // transform(val:number): number {
    //     return val*val;
    // }
    transform(val:number, exponent:number): number {
        return Math.pow(val, exponent);
    }
}