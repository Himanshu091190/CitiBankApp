function addValues(a:number,b:number) {
    var c = a + b;
    return c;
}

function squareValues(a:number) {
    var c = a * a;
    return c;
}

function loginValues(username:string, password:string) {
    username = "himanshu";
    password = "sharma";
    return username+password;
}

it("My simple Test Case", () => {
    var actualResult = addValues(10,20);
    var expectedResult = 30;

    expect(actualResult).toBe(expectedResult);
});

it("My Square Test Case", () => {
    var actualResult = squareValues(10);
    var expectedResult = 100;

    expect(actualResult).toBe(expectedResult);
});
it("My Login Test Case", () => {
    var actualResult = loginValues("Rohit","Sharma");
    var expectedResult = "himanshusharma";

    expect(actualResult).toBe(expectedResult);
});