import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent{

  title = 'Angular Reactive Forms';
  addShopFormGroup = new FormGroup({
    shopName: new FormControl('', [Validators.required, Validators.minLength(5), Validators.maxLength(20)]),
    shopAddress: new FormControl('', [Validators.required, Validators.maxLength(200)]),
  });
  constructor() { }
  ngOnInit() {
  }
  onSubmit() {
    console.warn(this.addShopFormGroup.value);
  }

}

