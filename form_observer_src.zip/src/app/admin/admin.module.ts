import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SqrtPipe } from '../app.sqrt';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { ContactUsComponent } from '../contact-us/contact-us.component';
import { AboutUsComponent } from '../about-us/about-us.component';



@NgModule({
  declarations: [
    SqrtPipe,
    DashboardComponent,
    AboutUsComponent
    // ContactUsComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    SqrtPipe,
    DashboardComponent,
    AboutUsComponent
    // ContactUsComponent
  ]
})
export class AdminModule { }
