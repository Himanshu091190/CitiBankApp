import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
@Injectable()
export class DashboardServiceService {

  log(message: any) {
    console.log(message);
  }

  getTotalEmployeesSummary(): any[]  {
    var TotalEmployeesSummary = [
      {Region: "EAST", TotalStrength: 50, unUsedStrength: 20},
      {Region: "WEST", TotalStrength: 40, unUsedStrength: 10},
      {Region: "NORTH", TotalStrength: 30, unUsedStrength: 5},
      {Region: "SOUTH", TotalStrength :45, unUsedStrength: 13},
      {Region: "CENTRAL", TotalStrength: 55, unUsedStrength: 18}
    ];
    return TotalEmployeesSummary;
  }
}
