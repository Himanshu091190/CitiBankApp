import { Product } from "./product";

export class ProductService {
    public getProducts() {
        let products: Product[];

        products = [
            new Product(1, 'Memory Card', 500),
            new Product(1, 'Pen Drive', 750),
            new Product(1, 'Power Bank', 100),
            new Product(1, 'Laptop', 1750),
            new Product(1, 'Mobile', 250)
        ]

        return products;
    }
}