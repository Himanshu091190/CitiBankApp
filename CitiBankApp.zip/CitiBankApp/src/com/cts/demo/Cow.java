package com.cts.demo;

public class Cow extends Animal{
	
	@Override
	public void animalType() {
//		super.animalType();
		System.out.println("I am given and assigned type as 'Indian Cow'");
	}
	
	@Override
	public void animalType(String type) {
//		super.animalType(type);
		System.out.println("Hey I have been assigned Type as " + type);
		type = "Herbivores";
		System.out.println("Hey I have been Re-assigned Type as  " + type + " to demonstrate method overriding ");
	}

}
