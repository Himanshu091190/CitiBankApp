package com.cts.demo;

public class FirstClass {

//	static int i=4;
//	public static  void demo() {
//		System.out.println("This is a demo method");
//	}
	
	 int i=4;
	public void demo() {
		System.out.println("This is a demo method");
	}
	
	public static void main(String[] args) {
		FirstClass mObject = new FirstClass();
		System.out.println(mObject.i);
		mObject.demo();
		
		for(int i=0; i<5; i++) 
			System.out.println("for: " +i);
		
		int j=0;
		while(j<5) {
			System.out.println("while: "+ j);
			j++;
		}
		
		int k=0;
		do {
			System.out.println("do while: "+k);
			k++;
		}while(k<5);
		
		int a = 3;
		switch(a) {
		case 1: System.out.println("It is 1");break;
		case 2: System.out.println("It is 2");break;
		case 3: System.out.println("It is 3");break;
		default: System.out.println("This is default");
		}
		
		char r = 'H';
		switch(r) {
		case 'H': System.out.println("It is H");break;
		case 'K': System.out.println("It is K");break;
		case 'M': System.out.println("It is M");break;
		default: System.out.println("This is default");
		}
		
//		for(int i= 1; i<=5; i++){
//			for(int j1 = 1; j1<=i; j1++){
//			System.out.print(i+" ");
//			}
//			}
//
//			for(int i=5; i>=1;i--){
//			for(int j1 =5; j1>i; j1--){
//			System.out.print(i+" ");
//			}
//			System.out.print("\n");
//			}
		
//		int n=10;
//		for (int i=1;i<=n;i++)
//		{
//		    if(i==6)
//		    {
//		        System.out.print("\n");
//		    }
//		    System.out.print(i+" ");
//		}
//		System.out.print("\n");
//		while(n!=0)
//		{
//		    System.out.print(n--
//		    +" ");
//		    if(n==5)
//		    {
//		        System.out.print("\n");
//		    }
//		}
//		
		
//		int n=5;
//		for(int i=1;i<=n;i++)
//		{   
//		    for(int j1=1;j1<=i;j1++)
//		    {
//		        System.out.print(i);
//		    }
//		    System.out.print("\n");
//		}
		
//		for(int i=5;i>=1;i--)
//		{   
//		    for(int j1=1;j1<=i;j1++)
//		    {
//		        System.out.print(i);
//		    }
//		    System.out.print("\n");
//		}
		
//		 int n=5;
//		  for(int i=1;i<=n;i++)
//		  {   
//		      for(int j1=1;j1<=i;j1++)
//		      {
//		          System.out.print(i+" ");
//		      }
//		      System.out.print("\n");
//		  }
//		  for(int i=n;i>=1;i--)
//		  {   
//		      for(int j1=1;j1<=i;j1++)
//		      {
//		          System.out.print(i+" ");
//		      }
//		      System.out.print("\n");
//		  }
		
//		int n=10;
//		  for (int i=1;i<=n;i++)
//		  {
//		      if(i==6)
//		      {
//		          System.out.print("\n");
//		      }
//		      System.out.print(i+" ");
//		  }
//		  System.out.print("\n");
//		  while(n!=0)
//		  {
//		      System.out.print(n--
//		      +" ");
//		      if(n==5)
//		      {
//		          System.out.print("\n");
//		      }
//		  }
		
//		int n=5;
//		for(int i=1;i<=n;i++)
//		{   
//		    for(int j1=1;j1<=i;j1++)
//		    {
//		        System.out.print(i+" ");
//		    }
//		    System.out.print("\n");
//		}
//		for(int i=n;i>=1;i--)
//		{   
//		    for(int j1=1;j1<=i;j1++)
//		    {
//		        System.out.print(i+" ");
//		    }
//		    System.out.print("\n");
//		}
		
		int n=10;
		for (int i=1;i<=n;i++)
		{
		    if(i==6)
		    {
		        System.out.print("\n");
		    }
		    System.out.print(i+" ");
		}
		System.out.print("\n");
		while(n!=0)
		{
		    System.out.print(n--
		    +" ");
		    if(n==5)
		    {
		        System.out.print("\n");
		    }
		}
	}
	
}
