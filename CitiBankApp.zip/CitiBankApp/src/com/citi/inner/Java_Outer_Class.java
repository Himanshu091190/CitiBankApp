package com.citi.inner;

public class Java_Outer_Class {
	private int data = 50;
	
	private class InnerClass {
		void message() {
			System.out.println("Data is " + data);
		}
	}
	
	public static void main(String[] args) {
		Java_Outer_Class obj = new Java_Outer_Class();
		Java_Outer_Class.InnerClass obj1 = obj.new InnerClass();
		
		obj1.message();
	}

}
