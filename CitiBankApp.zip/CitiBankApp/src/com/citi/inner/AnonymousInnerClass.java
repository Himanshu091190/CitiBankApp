package com.citi.inner;

abstract class Person {
	abstract void eat();
}


interface Sleeping {
	void sleep();
}

class AnonymousInnerClass {
	public static void main(String[] args) {
		Person p = new Person() {
			void eat() {
				System.out.println("Person eat fruits");
			}
		};
		
		p.eat();
		
	
	Sleeping sp = new Sleeping() {
		public void sleep() {
			System.out.println("Person Sleeps ");
		}
	};
	sp.sleep();
	}
}


