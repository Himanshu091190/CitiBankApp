package com.citi.oops;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MainClass {
	
	public static void main(String[] args) throws Exception {
		ICICI mICICI = null;
		HDFC mHDFC = null;

		System.out.println("Welcome to Indian Banking System\nPlease Select your bank\n1. ICICI\n2. HDFC");
		BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
		int bankChoice = Integer.parseInt(buff.readLine());
		
		switch(bankChoice) {
		case 1: mICICI = new ICICI();
				break;
		case 2: mHDFC = new HDFC();
				break;
		default: System.out.println("Wrong Choice");
		}
		
		if(mICICI != null ) {
			System.out.println("Please Create Your Account");
			mICICI.createAccount(buff);
			System.out.println("Which Operation you want to perform\n1. Deposit\n2. Withdrawl\n3. Open FD");
			int choice = Integer.parseInt(buff.readLine());
			switch(choice) {
			case 1: mICICI.deposit(buff); break;
			case 2: mICICI.withdrawl(buff); break;
			case 3: mICICI.openFD(buff); break;
			}
		}
		else if(mHDFC != null) {
			System.out.println("Please Create Your Account");
			mHDFC.createAccount(buff);
			System.out.println("Which Operation you want to perform\n1. Deposit\n2. Withdrawl\n3. Open FD");
			int choice = Integer.parseInt(buff.readLine());
			switch(choice) {
			case 1: mHDFC.deposit(buff); break;
			case 2: mHDFC.withdrawl(buff); break;
			case 3: mHDFC.openFD(buff); break;
			}
		}
	}

}
