package com.citi.java8;

import java.util.function.Predicate;

// Writing a Simple Predicate to get Implemented
public class PredicateInterfaceExample1 {
	public static void main(String[] args) {
		// Creating a Predicate
		Predicate<Integer> lesserthan = i -> (i < 18);
		
		// Calling the Predicate Method which we have created
		System.out.println(lesserthan.test(10));
	}
}
