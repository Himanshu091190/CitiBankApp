package com.citi.java8;

// Creating an Lambda Expression to find sum of two numbers
public class LambdaDemo2 {

	// creating a functional interface with a single abstract method
	interface MyInter1 {
		void add (int a, int b);
	}
	public static void main(String[] args) {
		MyInter1 mi = (int a, int b) -> { System.out.println("Sum is " + (a+b));};
		mi.add(10, 22);
		
		MyInterface3 mi3 = (int a, int b) -> { System.out.println("Difference is " + (a-b));};
		mi3.subtract(10, 22);
	}

}
