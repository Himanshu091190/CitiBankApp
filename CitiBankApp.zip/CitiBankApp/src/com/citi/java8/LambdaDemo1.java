package com.citi.java8;

// A lambda Expression to Display Some Message
public class LambdaDemo1 {

	// Create a functional interface with a single abstract method
	interface MyInter {
		void message();
	}
	public static void main(String[] args) {
		// Create functional interface reference that referes to the lambda expression
		MyInter mi = () -> {System.out.println("Hello Everyone Good Morning");};
		// call the method using the reference
		mi.message();
	}

}
