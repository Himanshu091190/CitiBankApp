package com.citi.java8;

// Creating an interface with a default method
interface MyInter {
	int add(int x, int y); // this is public and abstract
	default int mul(int x, int y) { // this is default method
		return (x*y);
	}
}
class A implements MyInter {
	@Override
	public int add(int x, int y) {
		return (x+y);
	}
}
public class DefaultDemo1 {
	public static void main(String[] args) {
		MyInter mi = new A();
		System.out.println("Sum is " + mi.add(10, 15));
		System.out.println("Product is " + mi.mul(10,15));
	}
}
