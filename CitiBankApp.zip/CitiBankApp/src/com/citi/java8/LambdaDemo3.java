package com.citi.java8;

// Creating a Lambda Expression that return square root value of a number
public class LambdaDemo3 {

	// Creating a functional interface with one abstract method
	interface MyInter2 {
		double squareroot(double num);
	}
	public static void main(String[] args) {
		// Creating a functional interface reference that refers to Lambda Expression
		MyInter2 mi = (double x) -> {return Math.sqrt(x);};
	
		
		// calling the method using reference
		System.out.println("Square root of 256 is " + mi.squareroot(256));
	}

}
