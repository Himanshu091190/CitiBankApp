package com.citi.java8;

// Double colon operator to refer to a method
public class DColonDemo1 {

	static void display() {
		System.out.println("Hello from Display Screen");
	}
	public static void main(String[] args) {
		// Creating Lambda Expression that represents the run method of a Runnable interface of Thread
		Runnable r1 = () -> System.out.println("Good Morning to all of you from Lambda Expresssion method");
		r1.run();
		
		// Double colon refers to the display method of DColon Class
		Runnable r2 = DColonDemo1::display;
		r2.run();
	}

}
