package com.citi.java8;

import java.util.function.Predicate;

// Implementing Predicate Chaining
public class PredicateInterfaceExample2 {
	public static void main(String[] args) {
		Predicate<Integer> greaterThanTen = (i) -> i > 10;
		
		Predicate<Integer> lesserThanTwenty = (i) -> i < 20;
		
		boolean result = greaterThanTen.and(lesserThanTwenty).test(15);
		
		System.out.println(result);
		
		// Calling Predicate Method
		boolean result2 = greaterThanTen.and(lesserThanTwenty).negate().test(15);
		System.out.println(result2);
	}
}
