package com.citi.java8;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamOperations {
	public static void main(String[] args) {
		// take a String type array and convert it into a list
		List<String> lst = Arrays.asList("USA", "Japan", "India", "China", "", "Russia", "uk");
		
		// count the no of strings with length more than 4 characters
		long n = lst.stream().filter(x -> x.length() > 4).count();
		System.out.println("No of Strings with length more than 4 characters are " + n);
		
		// count number of strings which startswith "U"
		n = lst.stream().filter(x -> x.startsWith("U")).count();
		System.out.println("No of Strings Starting with U are " + n);
		
		// remove all empty strings from the list and collect them into another list
		List<String> lst1 = lst.stream().filter(x -> !x.isEmpty()).collect(Collectors.toList());
		System.out.println("The List after removing the empty strings: \n" + lst1);
		
		// sort the stream and then convert into upper case and then collect into another list
		List<String> lst2 = lst1.stream().sorted().map(x->x.toUpperCase()).collect(Collectors.toList());
		System.out.println("The List after Sorting in Upper Case is:\n " + lst2);
		
		// convert all Strings to capital letters and collect them into an array
		String[] arr = lst2.stream().map(x -> x.toUpperCase()).toArray(String[]::new);
		System.out.println("Array of Sorted Strings in Uppercase: \n");
		for(String i: arr) System.out.print(i+",");
	}

}
