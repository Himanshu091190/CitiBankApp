package com.citi.java8;

public interface MyInterface3 {
	void subtract (int a, int b);
}
