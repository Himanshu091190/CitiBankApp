package com.citi.strings;

public class StringsTest {
	
	public static String stringTime() {
		String name = "Himanshu"; // It will create "Himanshu" as data in String constant pool where "name" will be considered as
		// reference variable and not an object
		
		// where as when you Create String as 
		// String name = new String("Himanshu");
		// In this case the "name" is considered as an Object in Heap memory referring to String class in Java
		for(int i=0; i<10000; i++)
			name += " Sharma";
		return name;
	}
	
	public static String stringBufferTime() {
		
		StringBuffer sb = new StringBuffer("Himanshu");
		for(int i=0; i<10000; i++)
			sb.append(" Sharma");
		
		return sb.toString();
	}
	
	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		
		stringTime();
		System.out.println("Time Take by String method: " + (System.currentTimeMillis() - startTime) + " ms");
	
		startTime = System.currentTimeMillis();
		stringBufferTime();
		System.out.println("Time Take by StringBuffer method: " + (System.currentTimeMillis() - startTime) + " ms");
		
		String name = new String("Himanshu");
		String name1 = new String("himanshu");
		String name2 = new String("Himanshu");
		
		System.out.println(name.hashCode());
		System.out.println(name1.hashCode());
		System.out.println(name2.hashCode());
	}

}
