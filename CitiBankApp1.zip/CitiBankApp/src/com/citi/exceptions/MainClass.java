package com.citi.exceptions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainClass {
	
	public static void validate(int age)  {
		if(age < 18)
			throw new ArithmeticException("Minor Person cannot caste his vote");
		else
			System.out.println("Eligible to cast his vote");
	}
	
	public static void main(String[] args) throws IOException {
		
		
		BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
		
		try {
			System.out.println("Enter your Name");
			String name = buff.readLine();
			System.out.println("Your Name is " + name);
			System.out.println("Enter your Age");
			int age = Integer.parseInt(buff.readLine());
			validate(age);
			
		
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		finally {
			buff.close();
		}
	}
}
