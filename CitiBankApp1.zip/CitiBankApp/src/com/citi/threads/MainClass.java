package com.citi.threads;

class ABC implements Runnable {

	@Override
	public void run() {
		for(int i=0; i<5; i++)
			System.out.println("I am in ABC Thread via Runnable Interface");
	}	
}

class DEF extends Thread {
	@Override
	public void run() {
		for(int i=0; i<5; i++)
			System.out.println("I am in DEF Thread via Thread class");
	}
}

class TestDaemonThread extends Thread {
	@Override
	public void run() {
		if(Thread.currentThread().isDaemon()) 
			System.out.println("This is a Daemon Thread");
		else
			System.out.println("This is a User Thread");
	}
}

public class MainClass {
	
	public static void main(String[] args) {
//		ABC obj = new ABC();
//		Thread t1 = new Thread(obj);
//		t1.start();
//		
//		DEF obj2 = new DEF();
//		obj2.start();
		
		TestDaemonThread t1 = new TestDaemonThread();
		TestDaemonThread t2 = new TestDaemonThread();
		TestDaemonThread t3 = new TestDaemonThread();
		
		t1.setDaemon(true);
		
		t1.start();
		t2.start();
		t3.start();
	}

}
