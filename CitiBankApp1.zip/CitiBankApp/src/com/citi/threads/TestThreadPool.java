package com.citi.threads;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class WorkerThread implements Runnable {

	String message;
	public WorkerThread(String str) {
		message = str;
	}
	
	@Override
	public void run() {
		// synchronized block to avoid deadlock
		synchronized (message) {
			System.out.println(Thread.currentThread().getName() +" (Start) and message is " + message);
			processMessage();
			System.out.println(Thread.currentThread().getName() + " (End) ");
		}
		
	}
	
	private void processMessage() {
		try {
			Thread.sleep(2000); // Waiting thread for 2 seconds
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}

public class TestThreadPool {
	public static void main(String[] args) {
		ExecutorService executor = Executors.newFixedThreadPool(5); // Creating a Pool of 5 Threads
		for(int i=0; i<10; i++) {
			Runnable worker = new WorkerThread("" + i);
			executor.execute(worker);
		}
		executor.shutdown();
		while(!executor.isTerminated()) {}
		System.out.println("Finished all Threads !!");
	}
}
