package com.citi.oops;

public class RBI {
	
	public void createAccount() {}
	public void deposit() {}
	public void withdrawl() {}
	public void openFD() {}

}
