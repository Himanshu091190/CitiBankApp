package com.citi.oops;

import java.io.BufferedReader;

public class ICICI extends RBI{
	
	int depositCounter = 0, withdrawlCounter = 0, minbal = 1000, bal = minbal;
	
	@Override
	public void createAccount() {
		super.createAccount();
	}
	
	public void createAccount(BufferedReader buff) throws Exception {
		System.out.println("Enter Your Name, Age and Address");
		String name = buff.readLine();
		int age = Integer.parseInt(buff.readLine());
		String address = buff.readLine();
		System.out.println("Your Details are " + name + " , " + age + " , " + address);
	}
	
	@Override
	public void deposit() {
		super.deposit();
	}
	
	public void deposit(BufferedReader buff) throws Exception {
		
			System.out.println("Enter the Amount to be added in your balance ");
			int amount = Integer.parseInt(buff.readLine());
			if(depositCounter > 3) 
				amount = (int) (amount - (0.2*amount));
			
			bal += amount;
			System.out.println("You have added " + amount + " balance");	
			depositCounter++;
	}

	
	@Override
	public void withdrawl() {
		super.withdrawl();
	}
	
	public void withdrawl(BufferedReader buff) throws Exception {
		System.out.println("Enter the Amount to be withdrawl");
		int withdrawl = Integer.parseInt(buff.readLine());
		
		if(withdrawlCounter > 3)
			withdrawl = (int) (withdrawl + (0.15*withdrawl));
		
		if((bal-withdrawl) > minbal) {
			bal -= withdrawl;
			System.out.println("You have withdrawl " + withdrawl + " and balance is " + bal);
		}
		else {
			System.out.println("You dont have sufficient balance after withdrawing the amount");	
		}
		
		withdrawlCounter++;
	}
	
	@Override
	public void openFD() {
		super.openFD();
	}
	
	public void openFD(BufferedReader buff) throws Exception {
		int roi = 5;
		System.out.println("Enter Amount, Years for Your FD");
		int amount = Integer.parseInt(buff.readLine());
		int years = Integer.parseInt(buff.readLine());
		System.out.println("Your maturity amount will be " + (amount * roi) * years);
	}

}
