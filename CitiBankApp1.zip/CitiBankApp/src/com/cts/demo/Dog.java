package com.cts.demo;

public class Dog extends Animal{
	
	@Override
	public void animalType() {
		super.animalType();
//		System.out.println("Dog Class: I am given and assigned type as 'Indian Dog'");
	}
	
	@Override
	public void animalType(String type) {
		super.animalType(type);
//		System.out.println("Dog Class: Hey I have been assigned Type as " + type);
//		type = "Carnivores and Herbivores";
//		System.out.println("Dog Class: Hey I have been Re-assigned Type as  " + type + " to demonstrate method overriding ");
	}

}
