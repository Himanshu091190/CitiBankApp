package com.cts.demo;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

public class SecondClass {

	public static void main(String[] args) throws Exception{
//		Scanner mScanner = new Scanner(System.in); // First Way of Accepting Input from User
//		System.out.println("Enter your Name");
//		String name = mScanner.next();
//		System.out.println("Your Name is: " + name);
		
		BufferedReader buff = new BufferedReader(new InputStreamReader(System.in)); // Second Way of Accepting from User
//		System.out.println("Enter your Name");
//		String fullName = buff.readLine();
//		System.out.println("Enter your Age");
//		int age = Integer.parseInt(buff.readLine());
//		System.out.println("Enter your Salary");
//		float salary = Float.parseFloat(buff.readLine());
//		System.out.println("Your Name is: " + fullName +" , Age is: " + age +" , Salary is: " + salary);
		

		Dog mDog = new Dog();
		mDog.animalType();
		mDog.animalType("Non-Vegetarian");
		
//		Cow mCow = new Cow();
//		mCow.animalType();
//		mCow.animalType("Vegetarian");
		
	}
}
