package com.cts.demo;

public class Animal {
	
	public void animalType() {
		System.out.println("Animal Type is Herbivorous");
	}
	
	private void animalColor() {
		System.out.println("Animal Color is by Default Black");
	}
	
	public void animalType(String type) {
		System.out.println("Animal Type is " + type);
	}
	
	private void animalColor(String color) {
		System.out.println("Animal Color is " + color);
	}

}
